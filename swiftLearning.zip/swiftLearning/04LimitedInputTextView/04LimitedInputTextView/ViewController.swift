//
//  ViewController.swift
//  04LimitedInputTextView
//
//  Created by slz on 2019/2/21.
//  Copyright © 2019年 slz. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITextViewDelegate{
    let textView = UITextView()
    let allowInputNumerLabel = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyBoardWillChangeNotification), name: UIResponder.keyboardWillChangeFrameNotification , object: nil)
        
        textView.frame = CGRect(x: 10, y: 20, width: self.view.bounds.width, height: 200)
        textView.delegate = self
        self.view.addSubview(textView)
        
        allowInputNumerLabel.text = "140"
        self.view.addSubview(allowInputNumerLabel)
        allowInputNumerLabel.frame = CGRect(x: self.view.frame.maxX - 60, y: self.view.frame.height - 40, width: 40, height: 20)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @objc func keyBoardWillChangeNotification(note: Notification) {
        let animationDrution = note.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as! TimeInterval
        let endFrame = (note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        
        let margin = UIScreen.main.bounds.height - endFrame.origin.y
        
        if margin > 0 {
            UIView.animate(withDuration: animationDrution) {
                self.allowInputNumerLabel.frame.origin.y = self.view.frame.height - margin - 50
            }
        }else{
            UIView.animate(withDuration: animationDrution) {
                self.allowInputNumerLabel.frame.origin.y = self.view.frame.height - 40
            }
        }
        
    }
    
    func textViewDidChange(_ textView: UITextView) {
        let count = textView.text.count
        self.allowInputNumerLabel.text = "\(140 - count)"
        
    }

}

