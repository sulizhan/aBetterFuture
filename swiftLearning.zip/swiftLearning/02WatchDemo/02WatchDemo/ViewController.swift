//
//  ViewController.swift
//  02WatchDemo
//
//  Created by slz on 2019/2/20.
//  Copyright © 2019年 slz. All rights reserved.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    var timeLabel : UILabel!
    var countTimer : Timer!
    var number : Float! = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.creatRightNavItme()
        self.view.backgroundColor = UIColor.white
        
        timeLabel = UILabel()
        timeLabel.font = UIFont.boldSystemFont(ofSize: 25)
        timeLabel.textAlignment = NSTextAlignment.center
        timeLabel.textColor = UIColor.black
        self.view.addSubview(timeLabel)
        timeLabel.text = "0.0"
        timeLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view)
            make.centerY.equalTo(self.view.snp.centerY).offset(-240)
        }

        let startButton = UIButton.init(type: UIButton.ButtonType.custom)
        startButton.addTarget(self, action: #selector(startAction), for: UIControl.Event.touchUpInside)
        startButton.setTitle("start", for: UIControl.State.normal)
        startButton.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        startButton.backgroundColor = .red
        self.view.addSubview(startButton)
        startButton.snp.makeConstraints { (make) in
            make.left.bottom.equalTo(self.view)
            make.top.equalTo(self.view.snp.centerY)
            make.right.equalTo(self.view.snp.centerX)
        }
        
        let endButton = UIButton.init(type: UIButton.ButtonType.custom)
        endButton.addTarget(self, action: #selector(endAction), for: UIControl.Event.touchUpInside)
        endButton.setTitle("end", for: UIControl.State.normal)
        endButton.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        endButton.backgroundColor = .blue
        self.view.addSubview(endButton)
        endButton.snp.makeConstraints { (make) in
            make.right.bottom.equalTo(self.view)
            make.top.equalTo(self.view.snp.centerY)
            make.left.equalTo(self.view.snp.centerX)
        }
        
        countTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { (_) in
            self.number += 0.1
            self.timeLabel.text = String.init(format: "%.2f", self.number)
        })
        countTimer.fire()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func creatRightNavItme() {
        let barItem = UIBarButtonItem.init(title: "reset", style: UIBarButtonItem.Style.plain, target: self, action: #selector(resetAction))
        self.navigationItem.rightBarButtonItem = barItem
    }

    @objc func resetAction() {
        self.number = 0.0
        self.timeLabel.text = String.init(format: "%.2f", self.number)
    }
    
    @objc func startAction() {
        if countTimer != nil {
            self.endAction()
        }
        countTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { (_) in
            self.number += 0.1
            self.timeLabel.text = String.init(format: "%.2f", self.number)
        })
        countTimer.fire()
    }
    
    @objc func endAction() {
        guard let timer = self.countTimer else {
            return
        }
        timer.invalidate()
    }
    

}

