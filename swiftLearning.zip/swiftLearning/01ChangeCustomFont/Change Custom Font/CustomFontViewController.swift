//
//  CustomFontViewController.swift
//  Change Custom Font
//
//  Created by slz on 2019/2/20.
//  Copyright © 2019年 slz. All rights reserved.
//

import UIKit
import SnapKit


class CustomFontViewController: UIViewController {
    var titleLabel : UILabel?
    var allFontNames : Array<String>?
    var timer : Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        
        func printAllSupportedFontNames() {
            let familyNames = UIFont.familyNames
            for familyName in familyNames {
                print("++++++ \(familyName)")
                let fontNames = UIFont.fontNames(forFamilyName: familyName)
                for fontName in fontNames {
                allFontNames?.append(fontName)
                    print("----- \(fontName)")
        }}}
        
        
        allFontNames = Array()
        
        
        printAllSupportedFontNames()
        
        
        
        self.view.backgroundColor = UIColor.white
        titleLabel = UILabel()
        titleLabel?.font = UIFont.systemFont(ofSize: 20)
        titleLabel?.textColor = UIColor.black
        titleLabel?.textAlignment = NSTextAlignment.center
        titleLabel?.text = "i am custom font label"
        self.view .addSubview(titleLabel!)
        titleLabel?.snp.makeConstraints({ (make) in
            make.center.equalTo(self.view)
        })
        
        let button = UIButton.init(type: UIButton.ButtonType.custom)
        self.view.addSubview(button)
        button.addTarget(self, action: #selector(buttonClick), for: UIControl.Event.touchUpInside)
        button.setTitle("change font", for: UIControl.State.normal)
        button.setTitleColor(UIColor.black, for: UIControl.State.normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.view)
            make.centerY.equalTo(self.view).offset(150)
        }
        
        
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { (_) in
            self.buttonClick()

        })
        timer?.fire()
        
        
        // Do any additional setup after loading the view.
    }
    
    @objc func buttonClick () {
        guard let arr = allFontNames else {
            return;
        }
        let tempX = UInt32(arr.count)
        let randomLetterNumber = arc4random()%tempX
        let intX = Int(randomLetterNumber)
        let nameString = allFontNames?[intX]
        titleLabel?.font = UIFont.init(name: nameString!, size: 20)
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
