//
//  ViewController.swift
//  Change Custom Font
//
//  Created by slz on 2019/2/20.
//  Copyright © 2019年 slz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

