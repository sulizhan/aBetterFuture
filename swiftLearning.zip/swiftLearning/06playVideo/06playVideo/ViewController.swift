//
//  ViewController.swift
//  06playVideo
//
//  Created by slz on 2019/2/22.
//  Copyright © 2019年 slz. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation
import MediaPlayer

class ViewController: UIViewController,AVAudioPlayerDelegate {
    var audioPalyer : AVAudioPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let videoButton = UIButton()
        videoButton.setTitleColor(UIColor.blue, for: .normal)
        videoButton.setTitle("Play Video", for: .normal)
        videoButton.frame = CGRect(x: 50, y: 50, width: 100, height: 50)
        self.view.addSubview(videoButton)
        videoButton.addTarget(self, action: #selector(playVideo), for: .touchUpInside)
        
        
        let audioPlayButton = UIButton()
        audioPlayButton.setTitleColor(UIColor.red, for: .normal)
        audioPlayButton.setTitle("Play Audio", for: .normal)
        audioPlayButton.frame = CGRect(x: 50, y: 150, width: 100, height: 50)
        self.view.addSubview(audioPlayButton)
        audioPlayButton.addTarget(self, action: #selector(playAudio), for: .touchUpInside)
        
        let audioPauseButton = UIButton()
        audioPauseButton.setTitleColor(UIColor.red, for: .normal)
        audioPauseButton.setTitle("Pause Audio", for: .normal)
        audioPauseButton.frame = CGRect(x: 50, y: 250, width: 100, height: 50)
        self.view.addSubview(audioPauseButton)
        audioPauseButton.addTarget(self, action: #selector(playAudio), for: .touchUpInside)
        
        // Do any additional setup after loading the view, typically from a nib.
        
        initAudioPalyer()
        UIApplication.shared.beginReceivingRemoteControlEvents()
        initForLockScreen()
    }

    
    
    @objc func playVideo() {
        let avConteroller = AVPlayerViewController()
        let url = URL(string: "http://down.treney.com/mov/test.mp4")
        guard let tempUrl = url else {
            return;
        }
        let plyer = AVPlayer(url: tempUrl)
        avConteroller.player = plyer
        self.present(avConteroller, animated: true) {}
    }
    
    @objc func pauseAudio() {
        audioPalyer?.pause()
    }
    
    @objc func playAudio() {
        audioPalyer?.play()
        
    }
    
    func initAudioPalyer() {
        let path = Bundle.main.path(forResource: "live", ofType: "mp3")
        let audioUrl = URL(fileURLWithPath: path!)

        do {
            audioPalyer = try AVAudioPlayer(contentsOf: audioUrl)
        } catch  {
            audioPalyer = nil
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback, mode: AVAudioSession.Mode(rawValue: ""), options: AVAudioSession.CategoryOptions.mixWithOthers)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("error")
        }
        
    }
    
    func initForLockScreen() {
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle:"皇后大道东",
            MPMediaItemPropertyArtist:"罗大佑",
            MPMediaItemPropertyArtwork:MPMediaItemArtwork(boundsSize: CGSize(width: 20, height: 20), requestHandler: { (image) -> UIImage in
                return UIImage(named: "thumb.jpg")!
            }),
            MPNowPlayingInfoPropertyPlaybackRate:1.0,
            MPMediaItemPropertyPlaybackDuration:"111",
            MPNowPlayingInfoPropertyElapsedPlaybackTime:"222"
        ]
    }
    
    override func remoteControlReceived(with event: UIEvent?) {
        switch event!.subtype {
        case .remoteControlPlay:
            audioPalyer?.play()
        case .remoteControlPause:
            audioPalyer?.pause()
        case .remoteControlStop:
            audioPalyer?.stop()
        default:
            break
        }
    }

}

