//
//  ViewController.swift
//  SimplePhotoBrowser
//
//  Created by slz on 2019/2/22.
//  Copyright © 2019年 slz. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate {
    let imageView = UIImageView()
    override func viewDidLoad() {
        super.viewDidLoad()
        let scrollView = UIScrollView()
        scrollView.frame = self.view.bounds
        scrollView.delegate = self
        scrollView.maximumZoomScale = 4.0
        scrollView.minimumZoomScale = 1.0
        scrollView.contentSize = self.view.bounds.size
        self.view.addSubview(scrollView)
        
        imageView.image = UIImage(named: "samplePhoto.jpeg")
        imageView.frame = self.view.bounds
        scrollView.addSubview(imageView)
        
        

        // Do any additional setup after loading the view, typically from a nib.
    }
    
     
    
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }

}

