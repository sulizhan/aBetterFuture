//
//  ViewController.swift
//  findMyPosition
//
//  Created by slz on 2019/2/21.
//  Copyright © 2019年 slz. All rights reserved.
//

import UIKit
import CoreLocation


class ViewController: UIViewController,CLLocationManagerDelegate{
    let enCoder = CLGeocoder()
    let locationLabel = UILabel()
    let locationManager = CLLocationManager()
    let positionLabel = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        locationLabel.frame = CGRect(x:100 , y: 200, width: 100, height: 100)
        locationLabel.textAlignment = .center
        locationLabel.textColor = .black
        locationLabel.font = UIFont.systemFont(ofSize: 20)
        self.view.addSubview(locationLabel)
        
        
        positionLabel.frame = CGRect(x:100 , y: 400, width: 100, height: 100)
        positionLabel.textAlignment = .center
        positionLabel.textColor = .black
        positionLabel.font = UIFont.systemFont(ofSize: 20)
        self.view.addSubview(positionLabel)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {

        let location = locations.last
        guard let tempLocation = location else{
            return;
        }
        let locationStr = String(format: "%d,%d", tempLocation.coordinate.latitude,tempLocation.coordinate.longitude)
        locationLabel.text = locationStr
        
        self.reversLocation(location: tempLocation) { (positionName) in
            self.positionLabel.text = positionName
        }
    }
    
    
    
    func reversLocation(location : CLLocation ,geoBlock : @escaping (_ positionName:String) -> ()) {
        enCoder.reverseGeocodeLocation(location) { (placeMark, error) in
            let tempArray = placeMark! as NSArray
            let mark = tempArray.firstObject as! CLPlacemark
            //                now begins the reverse geocode
            let addressDictionary = mark.addressDictionary! as NSDictionary
            let country = addressDictionary.value(forKey: "Country") as! String
            let city = addressDictionary.object(forKey: "City") as! String
            let street = addressDictionary.object(forKey: "Street") as! String
            
            let finalAddress = "\(street),\(city),\(country)"
            geoBlock("")
        }
    }
    

}

