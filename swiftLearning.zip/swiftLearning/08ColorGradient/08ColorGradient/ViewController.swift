//
//  ViewController.swift
//  08ColorGradient
//
//  Created by slz on 2019/2/25.
//  Copyright © 2019年 slz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var timeLabel : UILabel!
    var temperatureLabel : UILabel!
    var colorSets = [[CGColor]]()

    var gradientLayer: CAGradientLayer!
    var currentColorSet: Int!

    
    let brightestSkyColor_R = 21.0
    let brightestSkyColor_G = 105.0
    let brightestSkyColor_B = 203.0
    let darkestSkyColor_R = 8.0
    let darkestSkyColor_G = 33.0
    let darkestSkyColor_B = 63.0
    
    let lowestTemperature = 18
    let highestTemperature = 41
    
    let highestTemperatureColor_R = 255.0
    let highestTemperatureColor_G = 200.0
    let highestTemperatureColor_B = 101.0
    let lowestTemperatureColor_R = 47.0
    let lowestTemperatureColor_G = 169.0
    let lowestTemperatureColor_B = 199.0
    
    var totalIndex = 0

    
    var t1 = "我是字符串"
    var t2 = (age:18,"ligang")
    var array = Array<Int>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let digitNames = [
            0: "Zero", 1: "One", 2: "Two",   3: "Three", 4: "Four",
            5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
        ]
        
        array.append(11)
        array.append(25)
        array.append(337)

        let string =  array.map { (number) -> String in
            
            var number = number
            var output = ""
            
            repeat {
                output = digitNames[number%10]! + output
                number =  number/10
            }while number > 0
            
            return output
        }
        
        print(string)
        
        
        let panGestrue = UIPanGestureRecognizer(target: self, action: #selector(panAction))
        
        self.view.addGestureRecognizer(panGestrue)
        
        creatColors()

        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.createGradientLayer()
        
        timeLabel = UILabel(frame: CGRect(x: 50, y: 40, width: 100, height: 100))
        timeLabel.text = "1:00"
        timeLabel.textColor = UIColor.white
        timeLabel.font = UIFont.systemFont(ofSize: 28)
        self.view.addSubview(timeLabel)
        
        temperatureLabel = UILabel(frame: CGRect(x: 250, y: 40, width: 100, height: 100))
        temperatureLabel.text = "18 ℃"
        temperatureLabel.textColor = UIColor.white
        temperatureLabel.font = UIFont.systemFont(ofSize: 28)
        self.view.addSubview(temperatureLabel)
        
    }
    
    func createGradientLayer() {
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = self.view.bounds
        //设置渐变的主颜色
        gradientLayer.colors = colorSets[currentColorSet]
        //将gradientLayer作为子layer添加到主layer上
        self.view.layer.addSublayer(gradientLayer)
    }
    
    func creatColors() {
        for index in 1...12 {
           colorSets.append(ColorSet(index: Double(index)))
        }
        currentColorSet = 0
    }
    
    var lastY:CGFloat = 0.0, lastTotalIndex = 0, deltaOrigin = 0, indexForUp = 0
    @objc func panAction(gesture : UIPanGestureRecognizer){
        let velocity = gesture.velocity(in: self.view)
        let tranY = gesture.translation(in: self.view).y
        if lastY == 0 || tranY * lastY < 0{
            lastY = tranY
            lastTotalIndex = totalIndex
        }
        let scopeY = self.view.frame.height / 24.0
        //        time ++ up to down
        if velocity.y > 0 && totalIndex < 23{
            totalIndex = Int((tranY - lastY) /  scopeY)
            if totalIndex == 0 {
                deltaOrigin = lastTotalIndex
            }
            totalIndex += deltaOrigin
            lastTotalIndex = totalIndex
            //            print("time++ : index-> \(totalIndex)")
        }
        
        //        time -- down to up
        if velocity.y < 0 && totalIndex > 1{
            indexForUp = Int((tranY - lastY) / scopeY)
            if indexForUp == 0 {
                deltaOrigin = lastTotalIndex
            }
            totalIndex = deltaOrigin + indexForUp
            lastTotalIndex = totalIndex
        }
           self.changeColor()
           self.changeLabels()
    }
    
    func changeColor() {
        guard lastTotalIndex > 0 && lastTotalIndex < 24 else {
            return
        }
        UIView.animate(withDuration: 1) {
            
            if self.lastTotalIndex < 12 {
                self.gradientLayer.colors = self.colorSets[self.lastTotalIndex]
            }
            else {
                self.gradientLayer.colors = self.colorSets[23 - self.lastTotalIndex]
            }
        }
    }
    
    func changeLabels() {
        guard lastTotalIndex > 0 && lastTotalIndex < 25 else {
            return
        }
        if lastTotalIndex < 12 {
            temperatureLabel.text = "\(lowestTemperature + lastTotalIndex) ℃"
        }
        else {
            temperatureLabel.text = "\(highestTemperature - lastTotalIndex) ℃"
        }
        timeLabel.text = "\(lastTotalIndex):00"
    }
    
    func ColorSet(index: Double) -> Array<CGColor> {
        let sky_r = darkestSkyColor_R + (brightestSkyColor_R - darkestSkyColor_R) * (index - 1) / 11.0
        let sky_g = darkestSkyColor_G + (brightestSkyColor_G - darkestSkyColor_G) * (index - 1) / 11.0
        let sky_b = darkestSkyColor_B + (brightestSkyColor_B - darkestSkyColor_B) * (index - 1) / 11.0
        
        let tmpr_r = lowestTemperatureColor_R + (highestTemperatureColor_R - lowestTemperatureColor_R) * (index - 1) / 11.0
        let tmpr_g = lowestTemperatureColor_G + (highestTemperatureColor_G - lowestTemperatureColor_G) * (index - 1) / 11.0
        let tmpr_b = lowestTemperatureColor_B + (highestTemperatureColor_B - lowestTemperatureColor_B) * (index - 1) / 11.0
        
        return [UIColor(red: CGFloat(sky_r/255.0), green: CGFloat(sky_g/255.0), blue: CGFloat(sky_b/255.0), alpha: 1).cgColor,
                UIColor(red: CGFloat(tmpr_r/255.0), green: CGFloat(tmpr_g/255.0), blue: CGFloat(tmpr_b/255.0), alpha: 1).cgColor]
    }


}

